// ----------------------------------------------------------------------------------------------------
// Configuration settings for an xMatters Relevance Engine Integration
// ----------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------
// The url that will be used to inject events into xMatters.
// ----------------------------------------------------------------------------------------------------
WEB_SERVICE_URL = "https://https://xmsupport.hosted.xmatters.com/reapi/2015-04-01/forms/9041d879-b9ad-41f3-a48d-beb6b5665ff9/triggers";


// ----------------------------------------------------------------------------------------------------
// The location of the Nagios Command file for processing responses back to Nagios.
//  Example:  NAGIOS_COMMAND_FILE = "/usr/local/nagios/var/rw/nagios.cmd";
// ----------------------------------------------------------------------------------------------------
NAGIOS_COMMAND_FILE = "/usr/local/nagios/var/rw/nagios.cmd";

// ----------------------------------------------------------------------------------------------------
// Callbacks requested for this integration service.
// ----------------------------------------------------------------------------------------------------
CALLBACKS = ["status", "deliveryStatus", "response"];

// ----------------------------------------------------------------------------------------------------
// The username used to authenticate the request to xMatters.
// The user's password should be encrypted using the iapassword.sh utility.
// Please see the integration agent documentation for instructions.
// ----------------------------------------------------------------------------------------------------
INITIATOR = "nmonxi";
PASSWORD = "integrationservices/applications/nagios/.initiatorpasswd";

// ----------------------------------------------------------------------------------------------------
// Filter to use in <IAHOME>/conf/deduplicator-filter.xml
// ----------------------------------------------------------------------------------------------------
DEDUPLICATION_FILTER_NAME = "sample-relevance-engine";
